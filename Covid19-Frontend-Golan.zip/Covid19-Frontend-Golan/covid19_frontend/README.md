Author:Golan Isaschar

Front end part of covid19 project, I hope that everything good.

to rum this part please type into the terminal `npm start`
