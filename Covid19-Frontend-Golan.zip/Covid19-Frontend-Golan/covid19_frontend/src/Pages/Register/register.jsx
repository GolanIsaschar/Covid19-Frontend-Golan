import React, {useState} from "react";
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import axios from "axios";
import {useNavigate} from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import DatePicker from "react-datepicker";
import Checkbox from '@mui/material/Checkbox';
import LocalizationProvider from '@mui/lab/LocalizationProvider';
import {TextField} from "@mui/material";
import Button from '@mui/material/Button';
import FormControlLabel from '@mui/material/FormControlLabel';
import "react-datepicker/dist/react-datepicker.css";

const Register = () => {
    const navigator = useNavigate();
    const [FirstName, setFirstName] = useState('');
    const [LastName, setLastName] = useState('');
    const [City, setCity] = useState('');
    const [ZipCode, setZipCode] = useState('');
    const [LandLine, setLandLine] = useState('');
    const [PhoneNumber, setPhoneNumber] = useState('');
    const [Address, setAddress] = useState('');
    const [BirthDate, setDateOfBirth] = useState('');
    const [Infected, setCheckbox] = useState(false);
    const [errorMessage, setError] = useState('');

    const submitForm = async(e) =>{
        e.preventDefault();

        const data = {
            FirstName,
            LastName,
            City,
            ZipCode,
            LandLine,
            PhoneNumber,
            Address,
            BirthDate,
            Infected,
        }
        
        try{
            await axios.post('http://localhost:8000/register/',data);
            navigator('/summary');
        }

        catch (error) {
            if(typeof error.response == 'undefined')
                setError("Somethink wrong happent, Please try again later.")
            else
                setError(error.response.data.Error);
        }
    }

    const updateBirthDate = data => {
        if(data)
        {
            const BirthDateValue = `${data.getFullYear()}-${data.getMonth()+1}-${data.getDate()}`
            setDateOfBirth(BirthDateValue);
        }
    }

    return(
        <div>

            <Button  style={{left:'100px',position:'absolute'}}
                    onClick={() => navigator('/summary')}>Summary Page Link</Button>

            <div style={{ color: 'blue' }} className="d-flex mt-5 justify-content-center ">
                <h2 >Registration Page</h2>
            </div>


            <div className="d-flex justify-content-center">
                <div>
                    <form onSubmit={submitForm}>
                        <div>
                            <TextField error={!FirstName} className="mx-2 mt-3" 
                            id="filled-error" label="first name field" 
                            onChange={e => setFirstName(e.target.value)} />

                            <TextField error={!LastName} className="mx-2 mt-3" 
                            id="filled-error" label="last name field" 
                            onChange={e => setLastName(e.target.value)} />
                            
                            <TextField error={!City} className="mx-2 mt-3" 
                            id="filled-error" label="city field" 
                            onChange={e => setCity(e.target.value)} />

                            <TextField className="mx-2 mt-3" 
                            id="filled" label="zip code field (optional)" 
                            onChange={e => setZipCode(e.target.value)} />
                        </div>

                        <div>
                            <TextField error={!LandLine} className="mx-2 mt-3" 
                            id="filled-error" label="land line field"  
                            onChange={e => setLandLine(e.target.value)} />
                            
                            <TextField error={!PhoneNumber} className="mx-2 mt-3" 
                            id="filled-error" label="cellular phone field"  
                            onChange={e => setPhoneNumber(e.target.value)} />
                        
                            <TextField error={!Address} className="mx-2 mt-3" 
                            id="filled-error" label="address field"  
                            onChange={e => setAddress(e.target.value)} />

                        </div>    

                        <div className="d-flex  justify-content-center ">  
                        <LocalizationProvider dateAdapter={AdapterDateFns}>
                            <DatePicker
                                className = "mx-2 mt-3"
                                inputType = "dd/MM/yyyy"
                                value = {"Birth Date field" || BirthDate}
                                onChange = {(newDate) => {updateBirthDate(newDate)}}
                            />
                        </LocalizationProvider>


                            <FormControlLabel control={<Checkbox onChange={()=>setCheckbox(!Infected)}/>}
                                              label="I had COVID"/>
                            </div>
                            <div className="d-flex  justify-content-center ">
                            <Button type="submit">
                                Submit
                            </Button>
                            <p className="text-danger">{errorMessage}</p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    )
}

export default Register;