from django.db import models


class UserData(models.Model):
    Id = models.AutoField(primary_key=True)
    FirstName = models.CharField(max_length=30)
    LastName = models.CharField(max_length=30)
    City = models.CharField(max_length=30)
    ZipCode = models.IntegerField(null=True, blank=True)
    LandLine = models.CharField(max_length=30)
    Phone = models.IntegerField()
    Address = models.CharField(max_length=60)
    BirthDay = models.DateField()
    isInfected = models.BooleanField()
