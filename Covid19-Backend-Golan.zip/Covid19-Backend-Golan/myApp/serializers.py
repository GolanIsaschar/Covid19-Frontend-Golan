
from rest_framework import serializers
from myApp.models import UserData


class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserData
        fields = ('FirstName',
                  'LastName',
                  'City',
                  'ZipCode',
                  'LandLine',
                  'Phone',
                  'Address',
                  'BirthDay',
                  'isInfected'
                  )
