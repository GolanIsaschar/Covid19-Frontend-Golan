from rest_framework.decorators import api_view
from rest_framework.parsers import JSONParser
from myApp.models import UserData

from django.http.response import JsonResponse
from myApp.serializers import DepartmentSerializer


@api_view(['GET'])
def getData(request):
    dep = UserData.objects.all()
    dep_ser = DepartmentSerializer(dep, many=True)
    return JsonResponse(dep_ser.data, safe=False)


@api_view(['POST'])
def addData(request):
    JsonResponse.status_code = 200
    jsonData = JSONParser().parse(request)

    serializer = DepartmentSerializer(data=jsonData)
    if serializer.is_valid():
        serializer.save()
        JsonResponse.status_code = 200
        return JsonResponse({"message": "successfully"}, safe=False)

    JsonResponse.status_code = 400
    return JsonResponse({"message": "something wrong happent, Please try again"}, safe=False)
