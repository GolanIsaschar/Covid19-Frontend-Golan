from django.urls import path
from . import views

# declear the rout and what function each of url will do
urlpatterns = [
    path('', views.getData),
    path('savedata/', views.addData),
    path('register/', views.addData),
    path('summary/getData', views.getData),
]
