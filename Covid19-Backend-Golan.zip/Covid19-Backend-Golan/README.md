backend part Golan Isaschar

Terminal orders:
"pipenv shell"
"python manage.py runserver"
